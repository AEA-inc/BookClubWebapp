package Controller;

import Dao.BookDao;
import Model.Book;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "book", urlPatterns = {"/book", "/delete", "/edit", "/list"})
public class BookController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private BookDao bookDao;
    Gson map = new Gson();

    @Override
    public void init() throws ServletException {
        bookDao=new BookDao();

    }

    @Override
    protected void doGet(final HttpServletRequest req,final HttpServletResponse resp) throws ServletException, IOException {

        req.setAttribute("books", bookDao.getAllBooks());
        System.out.println(bookDao.getAllBooks());

      // req.getRequestDispatcher("addBook.jsp").forward(req, resp);
        String path = req.getServletPath();
        switch (path) {
            case "/list":
                list(req, resp);
                break;
            case "/delete":
                delete(req, resp);
                break;
            case "/edit":
                edit(req, resp);
                break;
            default: req.getRequestDispatcher("addBook.jsp").forward(req, resp);
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            addNewBook(req, resp);
    }


        private void delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
           String  id = request.getParameter("id");
           bookDao.deleteBook(id);
            response.sendRedirect("/book");
        }
        public void addNewBook(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
            String jsonSting = request.getParameter("book");
            Book book1 = map.fromJson(request.getParameter("book"), Book.class);

            bookDao.addBook(book1);

            PrintWriter out = response.getWriter();

            out.print(map.toJson(book1));
            //response.sendRedirect("addBook.jsp");

        }
    public void edit (HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        String id =request.getParameter("id");
       Book existingUser = bookDao.getBookById(id);
      //  addNewBook(request,response);
        request.setAttribute("retbook", existingUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("addBook.jsp");
        dispatcher.forward(request, response);


    }
    public void list (HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        request.setAttribute("books", bookDao.getAllBooks());
        System.out.println(bookDao.getAllBooks());
        request.getRequestDispatcher("addBook.jsp").forward(request, response);
    }
}
