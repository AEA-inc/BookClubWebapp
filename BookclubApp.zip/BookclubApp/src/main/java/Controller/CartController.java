package Controller;

import Dao.BookDao;
import Dao.CartDao;
import Model.Book;
import Model.Cart;
import Model.Member;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/checkout")
public class CartController extends HttpServlet {
    private CartDao dao = new CartDao();
    BookDao bookDao = new BookDao();
    Gson mapper = new Gson();
    @Override
    public void init() throws ServletException {
        dao = new CartDao();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        Member memberEmail = (Member) req.getAttribute("username");
//        System.out.print(memberEmail);
//        PrintWriter out = resp.getWriter();
//        String jsonString = req.getParameter("memberCheckout");
//        Cart checkout = mapper.fromJson(req.getParameter("memberCheckout"), Cart.class);
        HttpSession session = req.getSession();
        String username = (String) session.getAttribute("username");
//        dao.addProduct(checkout, username);
//        out.print(mapper.toJson(checkout));
        String isbn = req.getParameter("cartId");
        Book bookToAdd = bookDao.getBookById(isbn);
        String action = req.getParameter("action");
        Cart cart = dao.getCartByUsername(username);
        Cart checkingCart = new Cart();
        if (action.equals("add")) {
            cart = dao.getCartByUsername(username);
            if (cart == null) {
                cart = new Cart();
                dao.addCart(cart, username);
            }
            boolean canAdd = true;
            for (Book b : cart.getBooks()) {
                if (b.getIsbn() == bookToAdd.getIsbn()) canAdd = false;
            }
            if (canAdd) {
                dao.AddProductToCart(bookToAdd.getIsbn(), username);
                session.setAttribute("addMessage", "");
            } else {
                session.setAttribute("addMessage", "Item Already Exist");
            }
        } else if (action.equals("delete")) {
            boolean canDelete = false;
            for (Book b : cart.getBooks()) {
                if (b.getIsbn() == bookToAdd.getIsbn()) canDelete = true;
            }
            if (canDelete) {
                dao.deleteProduct(bookToAdd.getIsbn(), username);
                session.setAttribute("addMessage", "");
            } else {
                session.setAttribute("addMessage", "Item Not Found");
            }
        } else if (action.equals("pay")) {
            dao.checkOut(cart, username);
            checkingCart = dao.getCheckOutDB().get(username);
        } else if (action.equals("checkin")) {
            checkingCart = (Cart) session.getAttribute("cartCheckout");
            String id = req.getParameter("isbn");
            for (int i = 0; i<checkingCart.getBooks().size();i++) {
                if (checkingCart.getBooks().get(i).getIsbn().equals(id)) {
                    checkingCart.getBooks().get(i).setAvailable(true);
                }
            }
            req.getRequestDispatcher("viewBook.jsp").forward(req, resp);
        }
        session.setAttribute("cart", dao.getCartByUsername(username));
        session.setAttribute("cartCheckout", checkingCart);
        resp.sendRedirect("MemberBookCheckout.jsp");
    }
}

