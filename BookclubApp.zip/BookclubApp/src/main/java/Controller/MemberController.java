package Controller;

import javax.servlet.http.HttpServlet;

public class MemberController extends HttpServlet {

}
