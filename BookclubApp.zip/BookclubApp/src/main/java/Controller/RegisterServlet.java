package Controller;

import Dao.MemberDao;
import Model.Member;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {

    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstname= request.getParameter("firstName");
        String lastname=request.getParameter("lastName");
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        System.out.println(firstname);
        MemberDao memberDao=new MemberDao();
            Member member=new Member(firstname,lastname,email,password);
            String memberRegistered = memberDao.addMember(member);
            System.out.println(memberRegistered);
            if(memberRegistered.equals("SUCCESS"))
            {
                response.sendRedirect("welcome.jsp");
            }
            else
            {
                  response.sendRedirect("/register.jsp");
            }




    }
}
