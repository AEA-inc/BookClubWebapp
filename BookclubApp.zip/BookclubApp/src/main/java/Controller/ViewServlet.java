package Controller;
import Dao.MemberDao;
import Model.Member;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/view")
public class ViewServlet extends HttpServlet {
    //private static final long serialVersionUID = 1L;
    private MemberDao memberDao;
    Gson map = new Gson();
    @Override
    public void init() throws ServletException {
        memberDao=new MemberDao();
    }
    @Override
    protected void doGet(final HttpServletRequest req,final HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("members", memberDao.getAllMembers());
        System.out.println(memberDao.getAllMembers());
        req.getRequestDispatcher("Member.jsp").forward(req, resp);
     // response.sendRedirect("/view");
}

}
