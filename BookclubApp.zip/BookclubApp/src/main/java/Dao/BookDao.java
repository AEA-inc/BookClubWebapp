package Dao;

import Model.Book;
import com.google.gson.internal.bind.util.ISO8601Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BookDao {
    HashMap<String, Book> bookHashMap = new HashMap();

    {
        bookHashMap.put("11", new Book("11", "Java For Dummies", "someone", 677));
        bookHashMap.put("22", new Book("22", "Servlets and jsp", "everyone", 234));
        bookHashMap.put("33", new Book("33", "JavaScript for Begginers", "Noone", 10));
        bookHashMap.put("44", new Book("44", "HTML & CSs", "everybody", 45));

    }

    public void addBook(Book book) {
        System.out.println("adddd");
        bookHashMap.put(book.getIsbn(), book);


    }

    public List<Book> getAllBooks() {
////
        return new ArrayList<>(bookHashMap.values());
    }
    public void deleteBook(String id){
        System.out.println("delete");
        bookHashMap.remove(id);
    }
    public Book getBookById(String isbn){
        return bookHashMap.get(isbn);
    }


}


