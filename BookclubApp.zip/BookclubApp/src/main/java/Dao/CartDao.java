package Dao;

import Model.Book;
import Model.Cart;
import Model.Member;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CartDao {
    Member memb = new Member();
    BookDao bookDao = new BookDao();
    Map<String, Cart> productsDB = new HashMap<>();
    Map<String, Cart> checkOutDB = new HashMap<>();


    {
        // productsDB.put(1, new Cart(memb, 1, "book1", "aut1", 200.0));
    }

    public void addCart(Cart checkout, String username) {
        productsDB.put(username, checkout);
    }

    public Cart getCartByUsername(String username) {
        return productsDB.get(username);
    }

    public void deleteProduct(String productIsbn, String username) {
        Book bookToRemove = bookDao.getBookById(productIsbn);
        Cart currentCart = productsDB.get(username);
        currentCart.getBooks().remove(bookToRemove);
        currentCart.setTotalPrice(currentCart.getTotalPrice() - bookToRemove.getPrice());
    }

    public void AddProductToCart(String productIsbn, String username) {
        Book bookToRemove = bookDao.getBookById(productIsbn);
        Cart currentCart = productsDB.get(username);
        currentCart.getBooks().add(bookToRemove);
        bookToRemove.setAdded(true);
        currentCart.setTotalPrice(currentCart.getTotalPrice() + bookToRemove.getPrice());
    }

    public void checkOut(Cart cart, String username) {
        cart.getBooks().forEach(book -> book.setAvailable(false));
        checkOutDB.put(username, cart);
        productsDB = new HashMap<>();
    }

    public void checkIn(Cart cart, String isbn, String username) {
        cart = checkOutDB.get(username);
        for (Book book: cart.getBooks()) {
            if (book.getIsbn() == isbn) book.setAvailable(true);
        }
        //checkOutDB.remove(username, car);
    }


    public List<Cart> getAllProducts() {
        return new ArrayList<>(productsDB.values());
    }

    public Map<String, Cart> getCheckOutDB() {
        return checkOutDB;
    }

    public void setCheckOutDB(Map<String, Cart> checkOutDB) {
        this.checkOutDB = checkOutDB;
    }
}
