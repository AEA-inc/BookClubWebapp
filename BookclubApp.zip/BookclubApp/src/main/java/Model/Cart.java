package Model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    Member user;
    List<Book> books = new ArrayList<>();
    double totalPrice;

    public Cart(Member user, List<Book> books, double totalPrice) {
        this.user = user;
        this.books = books;
        this.totalPrice = totalPrice;
    }

    public Cart() {
        super();
    }

    public Member getUser() {
        return user;
    }

    public void setUser(Member user) {
        this.user = user;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
